const constants = {
  celsius: "C",
  farenheit: "F",
  cloudy: "cloudy",
  sunny: "sunny",
};

export default constants;
